# -*- coding: utf-8 -*-
#Pi_camera_NSE2019_2

# このソフトウェアはCanSatの画像処理用プログラムである
# 作成者：濱田真伍

# 2018年の機体Visionaryから本プログラムを使用している


import RPi.GPIO as GPIO
import smbus
#
import picamera
#
import numpy as np
import cv2
import time
#
import sys
import datetime
#todaydetail = datetime.datetime.today()
#file_name = todaydetail.strftime("%y%m%d_%H%M%S")
x_size=480
y_size=640
#S_SIZE = 0#red size
#------------------------------
def camera(t):
 with picamera.PiCamera() as ttom:
  ttom.resolution = (x_size,y_size)
#  ttom.start_preview()
  time.sleep(t) # warm-up
  ttom.capture('ttom.jpg')
#------------------------------
# 追跡対象の色範囲（Hueの値域）
def is_target(roi):
    return (roi <= 5) | (roi >= 180)#30,150

# マスクから面積最大ブロブの中心座標を算出
def max_moment_point(mask):
    # ラベリング処理
    label = cv2.connectedComponentsWithStats(mask)
    data = np.delete(label[2], 0, 0)   # ブロブのデータ
    center = np.delete(label[3], 0, 0) # 各ブロブの中心座標
    moment = data[:,4]                 # 各ブロブの面積
    max_index = np.argmax(moment)      # 面積最大のインデックス
#    return center[max_index]           # 面積最大のブロブの中心座標
    x,y =  center[max_index]
    S_SIZE = data[0,4]
    return x , y
# パーティクルの初期化
def initialize(img, N):
    mask = img.copy()                  # 画像のコピー
    mask[is_target(mask) == False] = 0 # マスク画像の作成（追跡対象外の色なら画素値0）
    x, y = max_moment_point(mask)      # マスクから面積最大ブロブの中心座標を算出
    w = calc_likelihood(x, y, img)     # 尤度の算出
    ps = np.ndarray((N, 3), dtype=np.float32) # パーティクル格納用の配列を生成
    ps[:] = [x, y, w]                  # パーティクル用配列に中心座標と尤度をセット
    return ps

# 1.リサンプリング(前状態の重みに応じてパーティクルを再選定)
def resampling(ps):
    # 累積重みの計算
    ws = ps[:, 2].cumsum()
    last_w = ws[ws.shape[0] - 1]
    # 新しいパーティクル用の空配列を生成
    new_ps = np.empty(ps.shape)
    # 前状態の重みに応じてパーティクルをリサンプリング（重みは1.0）
    for i in range(ps.shape[0]):
        w = np.random.rand() * last_w
        new_ps[i] = ps[(ws > w).argmax()]
        new_ps[i, 2] = 1.0

    return new_ps

# 2.推定（パーティクルの位置）
def predict_position(ps, var=13.0):
    # 分散に従ってランダムに少し位置をずらす
    ps[:, 0] += np.random.randn((ps.shape[0])) * var
    ps[:, 1] += np.random.randn((ps.shape[0])) * var

# 尤度の算出
def calc_likelihood(x, y, img, w=30, h=30):
    # 画像から座標(x,y)を中心とする幅w, 高さhの矩形領域の全画素を取得
    x1, y1 = max(0, x-w/2), max(0, y-h/2)
    x2, y2 = min(img.shape[1], x+w/2), min(img.shape[0], y+h/2)
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
    roi = img[y1:y2, x1:x2]
    # 矩形領域中に含まれる追跡対象(色)の存在率を尤度として計算
    count = roi[is_target(roi)].size
    return (float(count) / img.size) if count > 0 else 0.0001

# パーティクルの重み付け
def calc_weight(ps, img):
    # 尤度に従ってパーティクルの重み付け
    for i in range(ps.shape[0]):
        ps[i][2] = calc_likelihood(ps[i, 0], ps[i, 1], img)

    # 重みの正規化
    ps[:, 2] *= ps.shape[0] / ps[:, 2].sum()

# 3.観測（全パーティクルの重み付き平均を取得）
def observer(ps, img):
    # パーティクルの重み付け
    calc_weight(ps, img)
    # 重み和の計算
    x = (ps[:, 0] * ps[:, 2]).sum()
    y = (ps[:, 1] * ps[:, 2]).sum()
    # 重み付き平均を返す
    return (x, y) / ps[:, 2].sum()

# パーティクルフィルタ
def particle_filter(ps, img, N=300):
    # パーティクルが無い場合
    if ps is None:
        ps = initialize(img, N) # パーティクルを初期化

    ps = resampling(ps)    # 1.リサンプリング
    predict_position(ps)   # 2.推定
    x, y = observer(ps, img) # 3.観測
    return ps, int(x), int(y)
#----------------------------
path = "./ttom.jpg"
#-----------------------------

def main(todaydetail, file_name):
    ps = None

    # カメラのキャプチャ
    #cap = cv2.VideoCapture(0)

    t1=0
  #  while cv2.waitKey(60):
    while cv2.waitKey(60):
        frame = cv2.imread(path)

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV_FULL)
        h = hsv[:, :, 0]

        # S, Vを2値化（大津の手法）
        ret, s = cv2.threshold(hsv[:, :, 1], 0, 255, cv2.THRESH_BINARY|cv2.THRESH_OTSU)
        ret, v = cv2.threshold(hsv[:, :, 2], 0, 255, cv2.THRESH_BINARY|cv2.THRESH_OTSU)
        h[(s == 0) | (v == 0)] = 100

        # パーティクルフィルタ
        ps, x, y = particle_filter(ps, h, 300)

        if ps is None:
            continue
        # 画像の範囲内にあるパーティクルのみ取り出し
        ps1 = ps[(ps[:, 0] >= 0) & (ps[:, 0] < frame.shape[1]) &
                          (ps[:, 1] >= 0) & (ps[:, 1] < frame.shape[0])]
        # パーティクルをgreenで塗りつぶす
        for i in range(ps1.shape[0]):
            frame[int(ps1[i, 1]), int(ps1[i, 0])] = [10, 220, 0]
            # パーティクルの集中部分をgreen矩形で囲む
        cv2.rectangle(frame, (x-20, y-20), (x+20, y+20), (10, 220, 0), 5)
        print('x:{},y:{}'.format(x,y))
        # #print('x, y, s : {}, {}, {}'.format(x, y, S_SIZE))
   #     cv2.imshow('Result', frame)####################
        # print't:' ,t1
        print('t:{}'.format(t1))
        t1=t1+1
        time.sleep(0.1)
        if t1 >=2:#フレーム数
         #####
         with open('Pi_camera.txt', mode='a') as f:

          f.write('%s'%todaydetail.strftime("%y%m%d,%H%M%S,"))
          f.write('%d,'%x)
          f.write('%d\n'%y)
         ####
         r_frame = cv2.resize(frame,(y_size,x_size))
         cv2.imwrite("./ip_log/Pi_camera%s.jpg"%file_name,r_frame)

         break
##    cap.release()
    cv2.destroyAllWindows()

    return x


def get_ip_data():
  '''
  main.pyプログラムからこの関数を呼び出す．
  このimage_processing.pyはモジュールとしてインポートする．

  この関数が呼び出されたとき，カメラで撮影して，ゴールコーンの
  位置を返り値として返す．

  正面にある場合→０
  右側にある場合→１
  左側にあるばい→-1
  ゴールコーンを検出出来なかった場合→2019
  '''
  import datetime
  with open('image_process_log.txt', mode='a') as f:
    todaydetail = datetime.datetime.today() #現在時刻を取得
    f.write('\n')
    f.write('%s'%todaydetail.strftime("%y/%m/%d\n"))#年、月、日を記入
    f.write('ymd,hms,x,y \n')#年、月、日、時、分、秒、座標xyを入力
  
  try:
  #if GPIO.input(16) == GPIO.HIGH:
    import sys
    import datetime
    todaydetail = datetime.datetime.today()
    file_name = todaydetail.strftime("%y%m%d_%H%M%S")

#     GPIO.output(21,True)
    camera(2)#2秒間かけて撮影する
#     GPIO.output(21,False)
    x = main(todaydetail, file_name)
  #else:
  # print"waiting"
  # time.sleep(0.5)

    #パイカメラが逆さまに設置されていることに注意

    if x < x_size * 1/3:##ここあってる？（みずきちめも）
      flag = -1 #赤物体が右側に存在ことを示すフラグ

    elif x < x_size * 2/3:
      flag = 0 #赤物体が正面に存在ことを示すフラグ

    else:
      flag = 1 #赤物体が左側に存在ことを示すフラグ

  except ValueError:
    #print("Oops!  That was no valid number.  Try again...")
    print("Cannot detect object!")
    time.sleep(1.5)
    flag = 2017 #赤物体認識ができないことを示すフラグ

  return flag


#====================================================================
if __name__=="__main__":
  '''
  「 if name == 'main': 」ステートメントは
コマンドラインでファイルを指定して起動された場合は True で実行される
importでインポートされた場合は False で実行されない
  '''

  print("IP Software")
  print('IP flag = {}'.format(get_ip_data()))
#====================================================================


