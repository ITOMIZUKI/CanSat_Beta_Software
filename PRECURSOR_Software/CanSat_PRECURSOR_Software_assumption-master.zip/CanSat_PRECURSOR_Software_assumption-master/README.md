CanSat PRECURSOR Software
====

# 概要

このソフトウェアは，東北大学ロケット制作・打上サークルFROM THE EARTHのCanSat teamが作成したランバック部門のCanSat機体のソフトウェアである．

本ソフトウェアは，Python3 を用いて作成された．ミッション要求に基づいて仕様を満たせる様にコードを作成するように努めた．本ソフトウェアの開発期間は2018 年10 月から2019 年の8 月までの約1 年弱である．ソフトウェアはミッションフェーズに合わせて3 つのフェーズの動作を指定した関数をまとめたメソッドを用意してこれらを順番に実行していく．

# 作成者

阿部　瑞樹（Mizuki ABE）fte.mizuki[at]gmail.com  
濱田　真伍（Shingo HAMADA)  
伊藤　瑞輝（Mizuki ITO）

# 実行環境

本ソフトウェアの実行と開発に用いた環境を以下に示す

Rasbian 9.9  
Distributor ID: Raspbian  
Description: Raspbian GNU/Linux 9.9 (stretch)  
Release: 9.9  
Codename: stretch  
Python 3.5.3 (default, Sep 27 2018, 17:25:39)  
[GCC 6.3.0 20170516] on linux  
OpenCV：2.4.9.1  

# 更新日

2019/10/01
