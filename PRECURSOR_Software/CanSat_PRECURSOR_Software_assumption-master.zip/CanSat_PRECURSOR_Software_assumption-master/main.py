# _*_Coding: utf-8 _*_

# このプログラムは，2019年能代宇宙イベントCanSat競技に出場した
# PRECURSORのソフトウェアである．

# 作成者：阿部瑞樹（Mizuki ABE）
# 本プログラムは自由に改変して構わないが著作権は放棄しない．

# 本プログラムにはまだ修正すべき点，さらなる改良を加えられる点が存在する．
# 後輩諸君にこのプログラムを引き継ぐので，是非改良を加えてより良いプログラムを作成することを希望する．
"""
Main Program of CanSat
Calling each modules and methods from this
"""
import image_processing#画像処理のモジュールをインポート
import sensers#センサのモジュールをインポート
import steerage#制御入力を決定するプログラムのモジュールをインポート
import communication#ユーザーインターフェースに関連するモジュールをインポート
import control#アクチュエータの制御を行うモジュールをインポート


import os
import csv
import time
import datetime

class CanSat:
    """
    Fundamental Class for CanSat models

    description of member variables
        destination : GPS positon of destionation in format (latitude, longitude) tuple
        location : GPS position of current position in format [latitude, longitude] list
        altitude : altitude of rover
        euler : euler of rover in format [heading, roll, pitch]
        mag : magnetometer of rover [x, y, z]
        gyro : gyroscope [x, y, z]
        accel : accelerometer [x, y, z]
        direction : direction to destionation in format of 360 degrees
        distance : distance to destionation (meters)
        
    """

    def __init__(self):
        """
        constructor of CanSat instance
        """
        #info about position
        self.destination = self.define_destination()
        
        self.location = list()#initialize 
        self.gpsbool = False
        
        #info about the rover
        self.altitude = 0.00
        self.euler = list() #format [heading, roll, pitch]
        #self.axis = [0.0, 0.0, 0.0, 0.0]#format [sys, gyro, accel, mag]
        self.mag = list()
        self.gyro = list()
        self.accel = list()


        self.direction = 0.00
        self.distance = 0.00

        self.angular_difference = 0.00


        self.helm = None
        #read the file number
        #記録の際は連番をファイル名につけて，記録が上書きされないようにしている．連番はfile_number.txtに記録される様になっており，毎回これを読み込んで今回の実行の番号を決定する．
        try:
            with open('file_number.txt', 'r') as f:
                self.file_number = int(f.read())
                #print(type(self.file_number))
                #print(self.file_number)

        except:
            print("fail to read file_number.txt!")
        
        #generate file name
        self.data_log_file_name = "/home/pi/Desktop/CanSat-Alpha-Software/datalog/data_log_" + str(self.file_number) + ".csv"

        #write the new file number
        #　新たな連番を記録する．この値は次回のプログラム実行時に用いられる．
        try:
            with open('file_number.txt', 'w') as f:
                buf = str(self.file_number + 1)
                f.write(buf)

        except:
            print("fail to write file_number.txt!")     

        #generate file name
        self.control_log_file_name = "/home/pi/Desktop/CanSat-Alpha-Software/control_log/control_log_" + str(self.file_number) + ".csv"
        #make the data log file
        try:
            with open(self.data_log_file_name, "w", encoding = "utf-8", newline = '') as f:
                w = csv.writer(f, delimiter = ",")
                #sum up all lists and write
                buf = ['timestamp_hours','timestamp_minutes','timestamp_seconds','latitude','longitude','pressure[hPa]','temperature[degC]','humidity[percent]', 'altitude', 'heading', 'roll', 'pitch', 'mag_x', 'mag_y', 'mag_z', 'gyro_x', 'gyro_y', 'gyro_z', 'accel_x', 'accel_y', 'accel_z', 'distance', 'direction']
                print(buf)
                w.writerow(buf)

        except:
            print("fail to save the flight data!")

        
        #make the data log file
        try:
            with open(self.control_log_file_name, "w", encoding = "utf-8", newline = '') as f:
                w = csv.writer(f, delimiter = ",")
                #sum up all lists and write
                buf = ['latitude', 'longitude', 'distance', 'direction', 'helm']
                print(buf)
                w.writerow(buf)

        except:
            print("fail to save the control data!")
            
        return   
    
    def motor_test(self):
        '''
        モータのテスト動作を行うための関数
        '''
        communication.im920_send('initiating motor test now')
        communication.lighting(0b11100111)
        control.straight(100)
        time.sleep(5)
        communication.lighting(0b00100111)
        control.turnR(100)
        time.sleep(5)
        communication.lighting(0b11100100)
        control.turnL(100)
        time.sleep(5)
        communication.lighting(0b10100101)
        control.rover_brake()
        time.sleep(1)
        communication.lighting(0b01100110)
        control.rover_stop()
        time.sleep(1)

        communication.lighting(0b00000000)

    def define_destination(self):
        """
        Defines GPS Position of destionation from file
        Returns tuple of GPS position in format (latitude, longitude)
        """
        with open("destination.txt", "r") as f:
            buf = f.read()
            #print(buf)
            buf = buf.split()
            #print(buf)
            #change the type of each elements
            buf = [float(s) for s in buf]
        
        return tuple(buf)#split and make it tuple
    
    def update_atitude(self):
        """
        update atitude variables by reading sensors
        センサの情報を読み取って，メンバ変数に格納している
        """

        self.nowtime = (sensers.gps.timestamp[0], sensers.gps.timestamp[1], sensers.gps.timestamp[2])
        self.location = sensers.getGPS_position()
        if self.location[0] == 0 and self.location[1] == 0:
            self.gpsbool = True
        else:
            self.gpsbool = False
        #print(type(self.location))

        self.environment = sensers.read_env_data()
        
        self.altitude = sensers.calc_altitude(self.environment[0])

        self.euler = sensers.read_imu_euler()
        #print(type(self.euler))

        self.mag = sensers.read_imu_mag()
        #print(type(self.mag))
        self.gyro = sensers.read_imu_gyro()
        #print(type(self.gyro))
        self.accel = sensers.read_imu_accel()
        #print(type(self.accel))

        self.distance, self.direction = steerage.get_distance_rad(self.location, self.destination)
        #print(type(self.distance))
        #print(type(self.direction))

        # self.print_status()
        self.data_log()
    
    def print_status(self):
        '''
        ステータスを表示するための関数
        '''
        print('timestamp : {}'.format(self.nowtime))
        print('location : {}'.format(self.location))
        print('pressure : {}  temperature : {}  humidity : {}'.format(self.environment[0], self.environment[1], self.environment[2]))
        print('heading : {}  roll : {} pitch : {}'.format(self.euler[0],self.euler[1],self.euler[2]))
        print('mag   {}'.format(self.mag))
        print('gyro  {}'.format(self.gyro))
        print('accel {}'.format(self.accel))
        print('distance : {}  direction : {}'.format(self.distance, self.direction))

    def data_log(self):
        """
        save the sensor value as CSV file
        this is for flight analyis
        """
        try:
            with open(self.data_log_file_name, "a") as f:
                w = csv.writer(f, delimiter = ",")
                #sum up all tuples and write
                buf =list(self.nowtime) + list(self.location) + list(self.environment)
                buf.append(self.altitude)
                buf = buf + list(self.euler) + list(self.mag) + list(self.gyro) + list(self.accel)
                buf.append(self.distance)
                buf.append(self.direction)
                buf = [str(s) for s in buf]
                #print(buf)
                w.writerow(buf)

        except:
            print("fail to save the flight data!")
            
        return

    def calc_angular_difference(self):
        """
        目的地の方角と自身の進行方向の角度差を求める関数
        """
        if self.euler[0] > self.direction:
            angular_difference = self.euler[0] - self.direction
        else:
            angular_difference = self.direction - self.euler[0]

        if angular_difference >= 180:
            angular_difference = 360 - angular_difference

        #print('angular difference = {}'.format(angular_difference))

        return angular_difference


    def rover_derivation(self):
        #if self.gpsbool:
            #print("skip")
            #continue
        """
        ローバーを目的地に導く自動操縦の関数だよ！
        これはIMUとGPSによる制御のためのやつです
        即ちPhase2で用いるものである
        """
        P_GAIN = 0.001 #比例ゲイン

        print("ローバーの向いている方向：{}".format(self.euler[0]))

        #モータを回転させる秒数
        runtime = P_GAIN * self.calc_angular_difference()
        
        if self.helm == 0:
            # 直進方向
            communication.lighting(0b11000011)
            communication.im920_send('Go straight!')
            control.straight()
            time.sleep(1)

        elif self.helm == -1:
            # 左方向（角度差小）
            communication.lighting(0b00000011)
            communication.im920_send('Turn Right!')
            control.turnL()
            time.sleep(runtime)

        elif self.helm == -2:
            # 左方向（角度差大）
            communication.lighting(0b00000011)
            communication.im920_send('Turn Right more!')
            control.turnL()
            time.sleep(runtime)
        
        elif self.helm == 1:
            # 右方向（角度差小）
            communication.lighting(0b11000000)
            communication.im920_send('Turn Left!')
            control.turnR()
            time.sleep(runtime)

        elif self.helm == 2:
            # 右方向（角度差大）
            communication.lighting(0b11000000)
            communication.im920_send('Turn Left more!')
            control.turnR()
            time.sleep(runtime)

        communication.lighting(0b00000000)
        control.rover_stop()


    def rover_derivation_IP(self):
        #if self.gpsbool:
            #print("skip")
            #continue
        """
        ローバーを目的地に導く自動操縦の関数だよ！
        これは画像処理を用いて決定するものだよ
        ゲインを変えたりしてるよ
        """
        #P_GAIN = 0.001 #比例ゲイン

        print("ローバーの向いている方向：{}".format(self.euler[0]))

        #モータを回転させる秒数
        #runtime = P_GAIN * self.calc_angular_difference()
        runtime = 0.5 #画像処理を用いる場合は固定値

        if self.helm == 0:
            # 直進方向
            communication.lighting(0b11000011)
            communication.im920_send('Go straight!')
            control.straight()
            time.sleep(1)

        elif self.helm == -1:
            # 左方向（角度差小）
            communication.lighting(0b00000011)
            communication.im920_send('Turn Right!')
            control.turnL()
            time.sleep(runtime)

        elif self.helm == -2:
            # 左方向（角度差大）
            communication.lighting(0b00000011)
            communication.im920_send('Turn Right more!')
            control.turnL()
            time.sleep(runtime)
        
        elif self.helm == 1:
            # 右方向（角度差小）
            communication.lighting(0b11000000)
            communication.im920_send('Turn Left!')
            control.turnR()
            time.sleep(runtime)

        elif self.helm == 2:
            # 右方向（角度差大）
            communication.lighting(0b11000000)
            communication.im920_send('Turn Left more!')
            control.turnR()
            time.sleep(runtime)

        communication.lighting(0b00000000)
        control.rover_stop()

    def control_log(self):
        """
        save the control data as CSV file
        this is for control analysis
        制御履歴を残す関数だよ
        """
        try:
            with open(self.control_log_file_name, "a") as f:
                w = csv.writer(f, delimiter = ",")
                #sum up all lists and write
                buf = list(self.location) 
                buf.append(self.distance)
                buf.append(self.direction)
                buf.append(self.helm)
                buf = [str(s) for s in buf]
                w.writerow(buf)

        except:
            print("fail to save the control log")
            
        return    

    def imu_calibration(self):
        """
        キャリブレーションを行う関数
        すべてキャリブレーションするまで，俺らの夏は終わらないぜ！
        """
        while True:
            imu_status = sensers.read_imu_calibration_status()
            print('imu_status = {}'.format(imu_status))
            if imu_status == (3,3,3,3):
                """
                返り値は(sys_status, gyro_status, accel_status, mag_status)
                0=uncalibrated and 3=fully calibrated
                """
                return
            else:
                print('imu is not fully calibrated!\n')

    def phase1(self):
        '''
        Phase1の動作を規定するための関数だよ
        1回目の投下ではここのプログラムに不具合があったから上手く行かなかった
        2回めの投下に向けて応急修正を施したけど，本番では使ってないね
        '''
        
        try:
            with open(self.control_log_file_name, "a") as f:
                w = csv.writer(f, delimiter = ",")
                w.writerow('begin Phase1')

        except:
            print("fail to save the control data!")


        
        self.update_atitude()
        self.init_altitude = sensers.calc_altitude(cansat.environment[0])
        communication.im920_send('init_altitude = {}'.format(self.init_altitude))
        up_counter = 0 #上昇検知の回数を数えるカウンター

        while True:
            self.update_atitude()
            communication.lighting(0b00100100)
            communication.im920_send('alt = {}'.format(self.altitude))
            if self.altitude > self.init_altitude + 20:
                up_counter = up_counter + 1#閾値を超えたらカウントアップ
                communication.im920_send('up_counter = {}'.format(up_counter))
                if up_counter == 7:#七回連続ならばブレイク
                    
                    communication.im920_send('detect 20 m UP!')
                    break
            
            else:
                up_counter = 0#連続でカウントできなければカウンターをゼロに戻す
        
        down_counter = 0 #下降検知の回数を数えるカウンター

        while True:
            communication.im920_send('alt = {}'.format(self.altitude))
            self.update_atitude()
            communication.lighting(0b11000011)

            if self.altitude < self.init_altitude + 10:
                down_counter = down_counter + 1
                communication.im920_send('down_counter = {}'.format(down_counter))
                if down_counter == 7:
                    communication.im920_send('detect landing')
                    break

            else:
                down_counter = 0 #連続でカウント出来なければカウンターをゼロに戻す．

        time.sleep(5)

        control.rover_stop()
        control.straight()
        control.detach_para()
        time.sleep(15)
        control.rover_stop()
        
        return

    

    def phase2(self):
        '''
        Phase2の動作を規定したものだよ
        '''
        try:
            with open(self.control_log_file_name, "a") as f:
                w = csv.writer(f, delimiter = ",")
                w.writerow('begin Phase2')

        except:
            print("fail to save the control data!")

        while True:
            cansat.update_atitude()
            #print(cansat.gpsbool)
            if cansat.gpsbool:
                communication.im920_send('No GPS')
                continue

            self.helm = steerage.decideHelm(self.direction, self.euler[0])
            print("imu_helm = {}".format(self.helm))
            communication.im920_send('P2:IMU helm = {}'.format(self.helm))
            self.control_log()
            self.rover_derivation()

    def phase3(self):
        '''
        Phase3の動作を規定したものだよ！
        画像処理だね
        '''

        # 画像処理のカウンター
        counter = 0

        try:
            with open(self.control_log_file_name, "a") as f:
                w = csv.writer(f, delimiter = ",")
                w.writerow('begin Phase3')

        except:
            print("fail to save the control data!")

        while True:
            cansat.update_atitude()
            #print(cansat.gpsbool)
            if cansat.gpsbool:
                communication.im920_send('No GPS')
                continue

            self.helm = image_processing.get_ip_data()
            print("P3:ip_helm = {}".format(self.helm))
            communication.im920_send("P3:ip_helm = {}".format(self.helm))

            if self.helm == 2017:
                counter = counter + 1
            else:
                counter = 0
            
            if counter == 3:
                counter = 0
                self.helm = steerage.decideHelm(self.direction, self.euler[0])
                print("P3:No data imu_helm = {}".format(self.helm))
                communication.im920_send('P3:No data IMU helm = {}'.format(self.helm))
                
                    
                
            self.control_log()

            self.rover_derivation_IP()

        


# この上は全て動作を規定したメンバ関数がいっぱいある
# この下からがプログラムを実行して最初に呼び出される部分だよ

communication.im920_send('CanSat PRECURSOR Activation!')
cansat = CanSat()#CanSatクラスのインスタンス生成
control.rover_stop()

#cansat.motor_test()

cansat.imu_calibration()

# Phaseを順番に実行していく
cansat.phase1()
cansat.phase2()
cansat.phase3()


communication.im920_send('End of Program')

