import time
import serial 
import codecs 
import os 
import RPi.GPIO as GPIO

WARIKOMI = 8 
SCK = 36
RCK = 38
SI = 40

ser = serial.Serial("/dev/ttyUSB0",19200) 
GPIO.setmode(GPIO.BOARD)
GPIO.setup(WARIKOMI,GPIO.IN,GPIO.PUD_UP)
GPIO.setup(SCK, GPIO.OUT)
GPIO.setup(RCK, GPIO.OUT)
GPIO.setup(SI, GPIO.OUT)

def reset():
  GPIO.output(SCK, GPIO.LOW)
  GPIO.output(RCK, GPIO.LOW)
  GPIO.output(SI, GPIO.LOW)
 
def shift(PIN_NUM):
  GPIO.output(PIN_NUM, GPIO.HIGH)
  GPIO.output(PIN_NUM, GPIO.LOW)
 
def send_bits(data):
  for i in range(8):
    if ((1 << i ) & data) == 0:
      GPIO.output(SI, GPIO.LOW)
    else:
      GPIO.output(SI, GPIO.HIGH)
    shift(SCK)
  shift(RCK)

def lighting(bits):
  reset()
  send_bits(0)
  send_bits(bits)
  
def shutdown():
    print("shutdown by command...")
    time.sleep(1)
    os.system("sudo shutdown -h now")
	
def callBackTest(channel):
    shutdown()
	
def im920_receive():
    if(ser.inWaiting()):
        stock = (codecs.decode(ser.readline()).split(',')[2]).split(':')[1]
        print(stock)
        if(stock == 'shutdown\r\n'):
          shutdown()
		

GPIO.add_event_detect(WARIKOMI,GPIO.FALLING,callback = callBackTest,bouncetime = 300) 
while(1):
    im920_receive()
