# -*- Coding: utf-8 -*-

# このモジュールは舵角決定のプログラムである

import math

from math import sin
from math import cos
from math import tan
from math import atan2
from math import pi
from math import acos


def decideHelm(direction, heading):
    """
    This function generates helm
    direction: amplitude from current point to destination
    heading:amplitude that rover is heading
    return value indicates the helm
    """
    STRAIGHT_THRESHOLD = 15.0 #threshold of straight
    TURN_THRESHOLD = 50.0 #threshold of turn
    TURN_BIG_THRESHOLD = 180.0

    min_straight_a = direction - STRAIGHT_THRESHOLD
    if min_straight_a < 0:
        min_straight_b = 360 + min_straight_a
        min_straight_a = 0

    else:
        min_straight_b = float('inf')

    # print(min_straight_a)
    # print(min_straight_b)
    
    max_straight_a = direction + STRAIGHT_THRESHOLD
    if 360 <= max_straight_a:
        max_straight_b = max_straight_a - 360
        max_straight_a = 360

    else:
        max_straight_b = -float('inf')
    
    # print(max_straight_a)
    # print(max_straight_b)

    if min_straight_a <= heading <= max_straight_a or \
    min_straight_b <= heading < 360 or \
    0 <= heading <= max_straight_b:
        return 0

#######################################################
    min_turn_a = direction - TURN_THRESHOLD
    if min_turn_a < 0:
        min_turn_b = 360 + min_turn_a
        min_turn_a = 0
    else:
        min_turn_b = float('inf')

    # print(min_turn_a)
    # print(min_turn_b)

    max_turn_a = direction + TURN_THRESHOLD
    if 360 <= max_turn_a:
        max_turn_b = max_turn_a - 360
        max_turn_a = 360
    else:
        max_turn_b = -float('inf')
    
    # print(max_turn_a)
    # print(max_turn_b)

    if min_turn_a <= heading < min_straight_a or \
    min_turn_b <= heading <360 :
        return 1
    elif max_straight_a < heading <= max_turn_a or \
    0 <= heading <= max_turn_b :
        return -1

    ###################################################

    min_turn_a = direction - TURN_BIG_THRESHOLD
    if min_turn_a < 0:
        min_turn_b = 360 + min_turn_a
        min_turn_a = 0
    else:
        min_turn_b = float('inf')

    # print(min_turn_a)
    # print(min_turn_b)

    max_turn_a = direction + TURN_BIG_THRESHOLD
    if 360 <= max_turn_a:
        max_turn_b = max_turn_a - 360
        max_turn_a = 360
    else:
        max_turn_b = -float('inf')
    
    # print(max_turn_a)
    # print(max_turn_b)

    if min_turn_a <= heading < min_straight_a or \
    min_turn_b <= heading <360 :
        return 2
    elif max_straight_a < heading <= max_turn_a or \
    0 <= heading <= max_turn_b :
        return -2

def azimuth(x1, y1, x2, y2):
    # Radian角に修正
    _x1, _y1, _x2, _y2 = x1*pi/180, y1*pi/180, x2*pi/180, y2*pi/180
    Δx = _x2 - _x1
    _y = sin(Δx)
    _x = cos(_y1) * tan(_y2) - sin(_y1) * cos(Δx)

    psi = atan2(_y, _x) * 180 / pi
    if psi < 0:
        return 360 + atan2(_y, _x) * 180 / pi
    else:
        return atan2(_y, _x) * 180 / pi

def distance(x1, y1, x2, y2, r):
    _x1, _y1, _x2, _y2 = x1*pi/180, y1*pi/180, x2*pi/180, y2*pi/180
    Δx = _x2 - _x1
    val = sin(_y1) * sin(_y2) + cos(_y1) * cos(_y2) * cos(Δx)
    return r * acos(val)


def get_distance_rad(location, destination):

    x1 = location[1]
    #print(x1)
    y1 = location[0]
    #print(y1)
    x2 = destination[1]
    #print(x2)
    y2 = destination[0]
    #print(y2)
    r  = 6378.137e3

    direction = azimuth(x1, y1, x2, y2)
    dis = distance(x1, y1, x2, y2, r) 
    print("目的地までの方位角 : {0:.3f} 度".format(direction))
    print("目的地までの距離 : {0:.3f} m".format(dis))

    return dis ,direction
    #distance and direction

#print(get_distance_rad(*data))

#print(decideHelm(350,150))
