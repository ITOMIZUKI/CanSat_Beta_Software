# -*- Coding: utf-8 -*-
"""
This module is for man-machine interface
this module deals with IM920, onboard LED and other switches 
このモジュールは通信系とかの関数があるよ
"""

import time
import serial
import codecs
import os
import RPi.GPIO as GPIO

ser = serial.Serial("/dev/ttyUSB_IM920",19200)
#ラズパイのUSBデバイス名を変更したからこのデバイス名を指定する．
#GPIO.setmode(GPIO.BOARD)
pin = 7  #pin interrupt for button shutdown
#GPIO.setmode(GPIO.BOARD)
GPIO.setup(pin,GPIO.IN,GPIO.PUD_UP)

#CLEAN BUFFER FOR SECURE
def clean_buf():
  while(ser.inWaiting()):
    wastebox = ser.readline()

#RECEIVE
def im920_receive():
    if(ser.inWaiting()):
        stock = (codecs.decode(ser.readline()).split(',')[2]).split(':')[1]
        print(stock)
        if(stock == 'shutdown\r\n'):
          shutdown()

#"TXDT" AND "\r\n" ARE IM920'S COMMANDS
def im920_send(command):
    '''
    この関数の引数に，送信したい内容を入れて呼び出せば，IM920で送信できる
    '''
    ser.write(str.encode("TXDA"+str(command)+"\r\n"))
    time.sleep(1)
clean_buf()

def shutdown():
    print("shutdown by command...")
    time.sleep(1)
    os.system("sudo shutdown -h now")

def callBackTest(channel):
    shutdown()

#GPIO.add_event_detect(pin,GPIO.FALLING,callback = callBackTest,bouncetime = 300)

############shift_register#############
SCK = 36
RCK = 38
SI = 40
GPIO.setup(SCK, GPIO.OUT)
GPIO.setup(RCK, GPIO.OUT)
GPIO.setup(SI, GPIO.OUT)

def reset():
  GPIO.setup(SCK, GPIO.OUT)
  GPIO.setup(RCK, GPIO.OUT)
  GPIO.setup(SI, GPIO.OUT)
  GPIO.output(SCK, GPIO.LOW)
  GPIO.output(RCK, GPIO.LOW)
  GPIO.output(SI, GPIO.LOW)
 
def shift(PIN_NUM):
  GPIO.setup(SCK, GPIO.OUT)
  GPIO.setup(RCK, GPIO.OUT)
  GPIO.setup(SI, GPIO.OUT)
  GPIO.output(PIN_NUM, GPIO.HIGH)
  GPIO.output(PIN_NUM, GPIO.LOW)
 
def send_bits(data):
  GPIO.setup(SCK, GPIO.OUT)
  GPIO.setup(RCK, GPIO.OUT)
  GPIO.setup(SI, GPIO.OUT)
  for i in range(8):
    if ((1 << i ) & data) == 0:
      GPIO.output(SI, GPIO.LOW)
    else:
      GPIO.output(SI, GPIO.HIGH)
    shift(SCK)
  shift(RCK)
 
def lighting(bits):
  '''
  この関数の引数によってシフトレジスタの出力を調整するのだ
  '''
  reset()
  send_bits(0)
  send_bits(bits)
###################### 
#lighting(0b10000001)#
#time.sleep(3)       #
#lighting(0b00000000)#
#reset()             #
#GPIO.cleanup()      #
######################
 
lighting(0b10000001)
time.sleep(3)
lighting(0b00000000)
reset()
GPIO.cleanup()

