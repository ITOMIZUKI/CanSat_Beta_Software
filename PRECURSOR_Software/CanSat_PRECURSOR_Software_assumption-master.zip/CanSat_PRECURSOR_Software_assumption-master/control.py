# -*- Coding: utf-8 -*-

"""
This module is for control and manipulation of every subsystems of CanSat
このモジュールにはアクチュエータ類の制御を行うためのプログラムがいっぱい入っているよ
"""

import time
import RPi.GPIO as GPIO

#setup dc motors
#pin assign 
R_INA, R_INB = 26, 22
L_INA, L_INB = 31, 29
MOSFET_PIN = 16

class Motor:
    """
    モータのクラス
    """
    def __init__(self, INA, INB):
        """
        コンストラクタ
        """
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)#Pythical pin 
        #pinmode set
        GPIO.setup(INA, GPIO.OUT)
        GPIO.setup(INB, GPIO.OUT)


        self.INA = INA
        self.INB = INB


    def stop(self):
        GPIO.output(self.INA, GPIO.LOW)
        GPIO.output(self.INB, GPIO.LOW)
    
    def cw(self):
        GPIO.output(self.INA, GPIO.HIGH)
        GPIO.output(self.INB, GPIO.LOW)
    
    def ccw(self):
        GPIO.output(self.INA, GPIO.LOW)
        GPIO.output(self.INB, GPIO.HIGH)


    def brake(self):
        GPIO.output(self.INA, GPIO.HIGH)
        GPIO.output(self.INB, GPIO.HIGH)

motorR = Motor(R_INA, R_INB)
motorL = Motor(L_INA, L_INB)

def straight():
    '''
    直進
    '''
    motorR.cw()
    motorL.ccw()

def turnR():
    '''
    右回転
    '''
    motorR.ccw()
    motorL.ccw()

def turnL():
    '''
    左回転
    '''
    motorR.cw()
    motorL.cw()

def rover_stop():
    '''
    停止
    '''
    motorL.stop()
    motorR.stop()

def rover_brake():
    '''
    ブレーキ
    '''
    motorL.brake()
    motorR.brake()


"""
MOSFET for sub-career detach
"""
def mosfet(output):

    """
    argument defines HIGH and LOW
    HIGH: argument = 1
    LOW : argument = 0 or else
    """
    GPIO.setup(MOSFET_PIN, GPIO.OUT)
    GPIO.output(MOSFET_PIN, 0)
    GPIO.output(MOSFET_PIN, output)

def detach_para():
    mosfet(1)
    time.sleep(10)
    mosfet(0)
    return


#====================================================================
if __name__=="__main__":
    '''
    「 if name == 'main': 」ステートメントは
    コマンドラインでファイルを指定して起動された場合は True で実行される
    importでインポートされた場合は False で実行されない
    '''
  
    detach_para()
#====================================================================
